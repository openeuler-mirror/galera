/*
 * Copyright (C) 2009 Codership Oy <info@codership.com>
 */

#include "gcomm/uuid.hpp"


const gcomm::UUID gcomm::UUID::uuid_nil_ = gcomm::UUID(GU_UUID_NIL);



