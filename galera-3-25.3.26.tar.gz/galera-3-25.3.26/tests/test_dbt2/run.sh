#!/bin/sh

echo "Not implemented" > $GALERA_RESULT_DIR/out
exit 1
