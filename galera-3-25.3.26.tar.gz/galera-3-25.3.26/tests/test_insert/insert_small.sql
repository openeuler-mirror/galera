INSERT INTO test_insert VALUES (
DEFAULT,
RAND(),
CURRENT_DATE,
CURRENT_TIME,
'pokemon',
'drizzl'
);
