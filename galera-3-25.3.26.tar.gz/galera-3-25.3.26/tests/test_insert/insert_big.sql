INSERT INTO test_insert VALUES (
DEFAULT,
RAND(),
CURRENT_DATE,
CURRENT_TIME,
'pokemon forever',
'opwkmefovcm weofvowd  fowehvfe wehg ryu ki67 w2 fe4t5h ytryu76j tkutykuj 
thret h4t5 hjy5tyu6j rt hyj5t jty er w cda swc2trt45yu 65i 76ujt yhjn rhjr 
tj6yu7kjyt jt regt h4 hjytykiy ukhr4 hthtrjtyu7 tyu jty jtyjutykj 6tyu jt 
hr egge rgte tr5h rthyj ry5 kt dferht rt hjyurt hregftdefgwfrovppoodmpfpp 
owenj vfweovwjneokmemfdvcwoem wefvowkej 0o=0943i8t5 34fw=eri=we if jfowem
-jfwef =ojk frwe=fok wedfwoerj fwde  f23 c2dw xr5ju76 p0- 0= 7u kiki8 rtg
erf wefd qw fdehtr j k iuk o .lp 4 t5gvwed45w ty65 7u 987l9oimr tg wef d
qews xq d34 t5hg 65kji 87j 5t hg erw f 3wefjfdwpewofvdsf ofvkdspfpvsmvsd 
wefverfbvegfrbqwertyuiopsadfghjklzxcvbnm,.qwertyuiklopasdfghjkl  <zxcvbn
qwertyuiop[][poiuytrewq\wertyuioasdfghjklzxcvbnm,qwertyui<zxcvbnm€€€€€€€€
€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€€
1234567890-=~!@#$%^&*()_+bbvnmc,xnvmc,xbvnmc,xnvmc, vnkmc.xnmc,xnvmc swvfd
1234567890-=~!@#$%^&*()_+bbvnmc,xnvmc,xbvnmc,xnvmc,'
);
