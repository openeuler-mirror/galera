/*
 * Copyright (C) 2008 Codership Oy <info@codership.com>
 *
 * $Id$
 */

#ifndef __gcs_comp_test__
#define __gcs_comp_test__

extern Suite *gcs_comp_suite(void);

#endif /* __gu_comp_test__ */
