// Copyright (C) 2007 Codership Oy <info@codership.com>

// $Id$

#ifndef __gcs_fifo_test__
#define __gcs_fifo_test__

Suite *gcs_fifo_suite(void);

#endif /* __gcs_fifo_test__ */
