/*
 * Copyright (C) 2011 Codership Oy <info@codership.com>
 *
 * $Id$
 */

#ifndef __gcs_memb_test__
#define __gcs_memb_test__

extern Suite *gcs_memb_suite(void);

#endif /* __gu_group_test__ */
