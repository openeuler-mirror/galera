/*
 * Copyright (C) 2008 Codership Oy <info@codership.com>
 *
 * $Id$
 */

#ifndef __gcs_group_test__
#define __gcs_group_test__

extern Suite *gcs_group_suite(void);

#endif /* __gu_group_test__ */
