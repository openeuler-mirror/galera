// Copyright (C) 2007-2015 Codership Oy <info@codership.com>

// $Id$

#ifndef __gcs_state_msg_test__
#define __gcs_state_msg_test__

#include <check.h>

Suite *gcs_state_msg_suite(void);

#endif /* __gcs_state_msg_test__ */
