/*
 * Copyright (C) 2008-2015 Codership Oy <info@codership.com>
 *
 * $Id$
 */

#ifndef __gcs_proto_test__
#define __gcs_proto_test__

#include <check.h>

extern Suite *gcs_proto_suite(void);

#endif /* __gu_proto_test__ */
