/*
 * Copyright (C) 2008-2015 Codership Oy <info@codership.com>
 *
 * $Id$
 */

#ifndef __gcs_backend_test__
#define __gcs_backend_test__

#include <check.h>

extern Suite *gcs_backend_suite(void);

#endif /* __gu_backend_test__ */
