/*
 * Copyright (C) 2008-2015 Codership Oy <info@codership.com>
 *
 * $Id$
 */

#ifndef __gcs_node_test__
#define __gcs_node_test__

#include <check.h>

extern Suite *gcs_node_suite(void);

#endif /* __gu_node_test__ */
