// Copyright (C) 2007-2015 Codership Oy <info@codership.com>

// $Id$

#ifndef __gcs_sm_test__
#define __gcs_sm_test__

#include <check.h>

Suite *gcs_send_monitor_suite(void);

#endif /* __gcs_sm_test__ */
