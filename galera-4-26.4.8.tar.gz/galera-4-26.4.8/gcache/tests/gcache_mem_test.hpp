/*
 * Copyright (C) 2011 Codership Oy <info@codership.com>
 *
 * $Id$
 */
#ifndef __gcache_mem_test_hpp__
#define __gcache_mem_test_hpp__

extern "C" {
#include <check.h>
}

extern Suite* gcache_mem_suite();

#endif // __gcache_mem_test_hpp__
