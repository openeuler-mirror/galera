/*
 * Copyright (C) 2014 Codership Oy <info@codership.com>
 */
#ifndef GCOMM_PROTOCOL_VERSION_HPP
#define GCOMM_PROTOCOL_VERSION_HPP
#define GCOMM_PROTOCOL_MAX_VERSION 1
#endif // GCOMM_PROTOCOL_VERSION_HPP
